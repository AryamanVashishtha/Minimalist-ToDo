console.log("Scripts have loaded successfully");
